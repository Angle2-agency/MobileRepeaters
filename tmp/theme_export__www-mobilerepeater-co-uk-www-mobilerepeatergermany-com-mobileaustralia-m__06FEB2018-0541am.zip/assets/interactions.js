function getElementsByClass( searchClass, domNode, tagName) { 
  if (domNode == null) domNode = document;
  if (tagName == null) tagName = '*';
  var el = new Array();
  var tags = domNode.getElementsByTagName(tagName);
  var tcl = " "+searchClass+" ";
  for(i=0,j=0; i<tags.length; i++) { 
    var test = " " + tags[i].className + " ";
    if (test.indexOf(tcl) != -1) 
      el[j++] = tags[i];
  }
  return el;
} 
 
  function getParentByTagName(o, t) {
    if (!o) return false;
    if (o.tagName == t) return o;
    else return getParentByTagName(o.parentNode, t);
  }
  function nextObject(e) {
    do e = e.nextSibling;
    while (e && e.nodeType != 1);
    return e;
  }
  function prevObject(e) {
    do e = e.previousSibling;
    while (e && e.nodeType != 1);
    return e;
  }
  function parseJSON(text) {
    return eval('('+text+')');
  }
  function toCurrency(price) {
    if (price < 10) {
      price = '00' + price;
    } else if (price < 100) {
      price = '0' + price;			
    }
      price = price + '';
    var currency = document.getElementById('cart-amount-wrap').innerHTML.replace(/[0-9\.,]/g, ''),
        units = price.substring(0, price.length - 2),
        decimals = price.substring(price.length - 2, price.length);
    var format = /(\d+)(\d{3})/;
    while (format.test(units)) {
      units = units.replace(format, '$1' + ',' + '$2');
    }
    return currency + units + '.' + decimals;
  }
  function pluralize(sing, plural, number) {
    if (parseInt(number) == 1) {
      return number + ' ' + sing;
    } else {
      return number + ' ' + plural;
    }
  }
  
  function updateSummary(response) {
    if (response) {     
      var price = toCurrency(response.total_price),
          summary = document.getElementById('cart-link');
      document.getElementById('cart-amount-wrap').innerHTML = price;
      //document.getElementById('cart-item-count-wrap').innerHTML = pluralize('Items', 'items', response.item_count);
      document.getElementById('cart-item-count-wrap').innerHTML = response.item_count;
	  Shopify.updateCartInfo(response, '.widget_shopping_cart_content');      
      if (response.item_count == 0) {
        summary.className = summary.className.replace(' active', '');
      } else if (summary.className.indexOf('active') == -1) {
        summary.className += ' active';
      }
        if (document.getElementById('cart-total')) {
          document.getElementById('cart-total').innerHTML = price;
        }
    } else {
      if (window.XMLHttpRequest) {
        var request = new XMLHttpRequest();
        request.onreadystatechange = function() {
          if (request.readyState == 4 && request.status == 200) {
            var response = parseJSON(request.responseText);
            updateSummary(response);
          }
        }
        request.open('GET','/cart.js',true);
        request.send();
      }
    }
  }
  function documentWidth() {
    if (window.innerWidth) {
      return window.innerWidth;
    } else if(document.documentElement) {
      return document.documentElement.clientWidth;
    } else {
      return document.body.clientWidth;
    }
  }
  function addIncrements(el) {
    var minus = document.createElement('a'),
        plus = document.createElement('a');
    minus.href = plus.href = '#'
    minus.className = 'quantity-minus';
    minus.innerHTML = '&minus;';
    plus.className = 'quantity-plus';
    plus.innerHTML = '+';
    minus.onclick = function() {
      if (parseFloat(el.value) != 1) {
        el.value = parseFloat(el.value) - 1;
        if (document.getElementById('cart-form')) {
          var i = el.id.replace('quantity-', '');
          adjustQuantity(el.value, i);
        }
      }
      return false;
    }
    plus.onclick = function() {
      el.value = parseFloat(el.value) + 1;
      if (document.getElementById('cart-form')) {
        var i = el.id.replace('quantity-', '');
        adjustQuantity(el.value, i);
      }
      return false;
    }
    el.parentNode.insertBefore(minus, el);
    el.parentNode.insertBefore(plus, el.nextSibling);
  }
  //End helper functions
  
  //Carousel interaction
  (function() {
    if (document.getElementById('carousel-nav')) {
      var slides = document.getElementById('carousel-images'),
          slidesItems = slides.getElementsByTagName('li'),
          nav = document.getElementById('carousel-nav'),
          navItems = nav.getElementsByTagName('li'),
          current = 0,
          carousel_interval;
      
      function showSlide(i) {
        if (i != current && slidesItems[i]) {
          slide = slidesItems[i];
          slide.className += ' show';
          setTimeout (function() {
            slide.className = slide.className.replace('show', 'appear');					
          }, 1);
          setTimeout(function() {
            slidesItems[current].className = slidesItems[current].className.replace('current', '');
            slide.className = slide.className.replace('appear', 'current');
            current = i;
          }, 300);
          navItems[i+1].className += ' current';
          navItems[current+1].className = navItems[current+1].className.replace('current', '');
          if (i == 0) {
            if (navItems[0].className.indexOf('disabled') == -1) {
              navItems[0].className += ' disabled';
            }
          } else {
            navItems[0].className = navItems[0].className.replace(' disabled', '');
          }
          var l = navItems.length - 1;
          if (i == slidesItems.length - 1) {
            if (navItems[l].className.indexOf('disabled') == -1) {
              navItems[l].className += ' disabled';
            }
          } else {
            navItems[l].className = navItems[l].className.replace(' disabled', '');
          }
        }
      }
      
      function change_slide() {
        var c = current + 1;
        if (c >= slidesItems.length) { c = 0; }
        showSlide(c);
      }
      
      (function() {
        carousel_interval = setInterval(change_slide, 5000);
      })();
      
      nav.onclick = function(e) {
        e = e || window.event; e = e.target || e.srcElement;
        e = getParentByTagName(e, 'A');
        if (e) {
          var action = e.getAttribute('data-action');
          if (action == 'prev') {
            showSlide(current - 1);
          } else if (action == 'next') {
            showSlide(current + 1);
          } else {
            showSlide(parseInt(action));
          }
          clearInterval(carousel_interval);
        }
        return false;
      }
    }
  })();
  
  //Add to cart button
  (function() {
    if (document.getElementById('add-to-cart')) {
      var error = false,
          cart = document.getElementById('cart-link'),
          //cart_div = document.getElementById('cart-data'),
          add = document.getElementById('add'),
          message = document.createElement('div'),
          jGrowl_id = document.createElement('jGrowl'),
          timer;
      //message.className = 'message';
      
      function messageTimer() {
        clearTimeout(timer);
        timer = setTimeout(function() {          
          setTimeout(function(){
            //jGrowl_id.trigger("");
            //jGrowl_id.html('');
          }, 300);
        }, 10000);
      }
      
      function addToCart(q, i) {        
        if (window.XMLHttpRequest) {
          var request = new XMLHttpRequest();
          request.onreadystatechange = function() {
            if (request.readyState == 4 && request.responseText) {
              if (request.status == 200) {               
                var response = parseJSON(request.responseText);
                updateSummary();
                
                /*
                message.className = message.className.replace(' loading', '');
                message.innerHTML = '<strong>' + response.title + '</strong> added to cart';
                cart.appendChild(message);
                setTimeout(function() {
                  message.style.opacity = 1;					
                }, 10);
                messageTimer();
                */                  
                window.scrollTo(0,0);
                jslow(response);
                add.disabled = false;
              } else if (request.status == 500 || request.status == 422) {               
                add.disabled = false;
                var response = parseJSON(request.responseText);
                alert(response.description);
              } else {               
                add.disabled = false;
                error = true;
                document.getElementById('add-to-cart').submit();
              }
            }
          }
          request.open('POST','/cart/add.js?quantity='+q+'&id%5B%5D='+i,true);
          request.send();
          return true;
        }
        return false;
      };
      
      if (document.getElementById('add-to-cart')) {
        document.getElementById('add-to-cart').onsubmit = function(e) {         
          if (error != true) {
            //add.disabled = true;
            
            q = document.getElementById('quantity').value;
            v = document.getElementById('p_Vas').value;
            
            
            var CableUpgrade_addon_select = document.getElementById('cable-upgrade-addon');
            var CableUpgrade_addon = CableUpgrade_addon_select.options[CableUpgrade_addon_select.selectedIndex].value;
            if (CableUpgrade_addon && CableUpgrade_addon != "") {
            	v = CableUpgrade_addon + '&id%5B%5D=' + v;
            }
            
            
            var extended_warranty_addon_select = document.getElementById('extended-warranty-addon');
            var extended_warranty_addon = extended_warranty_addon_select.options[extended_warranty_addon_select.selectedIndex].value;
            if (extended_warranty_addon && extended_warranty_addon != "") {
            	v = extended_warranty_addon + '&id%5B%5D=' + v;
            }
            
            var vape_addons = getElementsByClass('extra-addon-input');
            if (vape_addons) {
              for (var i = 0; i < vape_addons.length; i++) {
                if (vape_addons[i].checked) {
                  if(vape_addons[i].value !=""){
                  	v = vape_addons[i].value + '&id%5B%5D=' + v;  
                  }                  
                }
              }
            }
            
            if (addToCart(q, v)) {
              return false;
            }
          }
          return true;
        }
      }
    }
    
    function jslow(response){  
        if (response) {
                var product_title = response.product_title;
                //$.jGrowl.defaults.closerTemplate = "<div>[ xxxxx ]</div>";
                $.jGrowl.defaults.appendTo = "div#jGrowl";
                var info = '<div class="row"><div class="col-md-8"><a href="'+ response.url +'"><img src="'+ Shopify.resizeImage(response.image, 'small') +'" alt="'+ response.title +'"/></a></div><div class="col-md-16"><div class="jGrowl-note">'+y_p+'<a href="/cart" class="your_cart">'+ y_c +'</a></div><a class="jGrowl-title" href="'+ response.url +'">'+ response.title +'</a></div></div>';
                 $.jGrowl(info, {
                   sticky: true,					
                 });
                //t_c();
          		updateSummary();
          		/*
                Shopify.getCart(function(cart) {      
                  Shopify.updateCartInfo(cart, '.widget_shopping_cart_content');		
                });*/   
     }
	}
    
  })();